from django.apps import AppConfig


class AdminAppConfig(AppConfig):
    name = 'Admin_app'
